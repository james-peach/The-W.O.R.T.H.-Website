/*$(document).ready(function(){
  $('.orgs-title').hide(); 
  $('.orgs-desc').hide(); 
  $('.detect-orgs-info-mouse-leave').hide(); 
  $('.orgs-pic-1').css({
    'bottom': '200px'
  });
  $('.orgs-pic-1').mouseenter(function(){
    $('.orgs-desc-1').show(); 
    $('.orgs-title-1').show(); 
    $('.orgs-pic-1').hide();
    $('.detect-orgs-info-mouse-leave-1').show(); 
  });  
  $('.detect-orgs-info-mouse-leave-1').mouseleave(function(){
    $('.orgs-pic-1').show(); 
    $('.orgs-pic-1').css({
      'position': 'relative', 
      'bottom': '50px'
    });
    $('.orgs-pic-3').css({
      'position': 'relative', 
      'top': '200px', 
    }); 
    $('.orgs-desc-1').hide(); 
    $('.orgs-title-1').hide(); 
    $('.orgs-desc-1').css({
      'position': 'relative', 
      'bottom': '780px',
    }); 
    $('orgs-title-1').show(); 
  }); 
    $('orgs-pic-3').mouseover(function(){
      $('.orgs-desc-3').show(); 
      $('.orgs-title-3').show(); 
    }); 
    $('detect-orgs-info-mouse-leave-3
}); 
*/ 

$(document).ready(function(){
  ('.detect-orgs-info-mouse-leave').hide(); 
}); 

